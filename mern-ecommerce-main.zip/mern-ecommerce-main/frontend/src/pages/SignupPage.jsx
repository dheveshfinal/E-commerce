import React from 'react'
import { Signup } from '../features/auth/components/Signup'

export const SignupPage = () => {
  return (
    <Signup/>
  )
}
